# Cronômetro Flutuante

Cronômetro `h:mm:ss.mmm`, fundo preto / texto branco, flutuante e arrastável.
Horas/min/seg em destaque e milissegundos menores; fica âmbar quando pausado.

- 1 toque: pausa / continua
- 2 toques: reinicia (zera e para)
- Arrastar: move (a posição é lembrada e fica sempre dentro da tela)
- Duas teclas configuráveis: **iniciar/pausar** e **reiniciar** (funcionam dentro de outros apps via serviço de acessibilidade)

## Como gerar o APK

**Opção A – GitHub (sem instalar nada)**
1. Crie um repositório e suba o conteúdo desta pasta.
2. Aba *Actions* → *Build APK* → rode (ou apenas faça o push).
3. Baixe o artefato `cronometro-apk` (contém `app-debug.apk`, já instalável).

**Opção B – Android Studio**
File → Open → escolha esta pasta → Build → Build APK(s).

## Uso
1. Abra o app → *Sobreposição de tela* → Ajustes → permitir.
2. Em *Teclas*, toque em *Definir* e pressione a tecla desejada (✕ remove).
3. *Serviço de acessibilidade* → Ajustes → Cronômetro Flutuante → ligar.
   No Android 13+ de app instalado fora da Play Store, pode ser preciso antes ir em
   Configurações → Apps → Cronômetro Flutuante → ⋮ → "Permitir configurações restritas".
4. *Mostrar cronômetro*.

As teclas escolhidas são consumidas enquanto o cronômetro estiver visível (não chegam ao jogo).
