package com.floattimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.WindowManager;

public class TimerService extends Service {

    /** Acessível pelo KeyService (mesmo processo, thread principal). */
    public static volatile TimerService instance;

    private static final String CHANNEL = "timer";

    private Choreographer choreographer;
    private WindowManager wm;
    private TimerView view;
    private WindowManager.LayoutParams lp;

    private boolean running;
    private long startNanos;   // relógio no último "start"
    private long accumNanos;   // acumulado até a última pausa

    /** Atualiza a tela uma vez por frame (sincronizado com o vsync) só enquanto roda. */
    private final Choreographer.FrameCallback frame = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            refresh();
            if (running) choreographer.postFrameCallback(this);
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        choreographer = Choreographer.getInstance();
        instance = this;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (view == null) createOverlay();
        return START_NOT_STICKY;
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (view != null) moveTo(lp.x, lp.y); // mantém dentro da tela após girar
    }

    @Override public void onDestroy() {
        instance = null;
        if (choreographer != null) choreographer.removeFrameCallback(frame);
        if (view != null && wm != null) {
            try { wm.removeView(view); } catch (Exception ignored) { }
            view = null;
        }
        super.onDestroy();
    }

    // ---------- controle do cronômetro ----------

    /** Inicia / pausa. */
    public void toggle() {
        long now = SystemClock.elapsedRealtimeNanos();
        if (running) {
            accumNanos += now - startNanos;
            running = false;
            choreographer.removeFrameCallback(frame);
        } else {
            startNanos = now;
            running = true;
            choreographer.postFrameCallback(frame);
        }
        refresh();
    }

    /** Zera e para. */
    public void reset() {
        running = false;
        accumNanos = 0;
        choreographer.removeFrameCallback(frame);
        refresh();
    }

    private void refresh() {
        if (view == null) return;
        long n = accumNanos;
        if (running) n += SystemClock.elapsedRealtimeNanos() - startNanos;
        int s = running ? TimerView.RUNNING : (accumNanos > 0 ? TimerView.PAUSED : TimerView.IDLE);
        view.update(n / 1_000_000L, s);
    }

    // ---------- overlay ----------

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private void moveTo(int x, int y) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxX = Math.max(0, dm.widthPixels - view.getWidth());
        int maxY = Math.max(0, dm.heightPixels - view.getHeight());
        lp.x = Math.max(0, Math.min(x, maxX));
        lp.y = Math.max(0, Math.min(y, maxY));
        wm.updateViewLayout(view, lp);
    }

    private void createOverlay() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        view = new TimerView(this);

        SharedPreferences sp = Prefs.get(this);
        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = sp.getInt(Prefs.POS_X, dp(16));
        lp.y = sp.getInt(Prefs.POS_Y, dp(40));

        final GestureDetector gd = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    int ix, iy;

                    @Override public boolean onDown(MotionEvent e) {
                        ix = lp.x;
                        iy = lp.y;
                        return true;
                    }

                    // 1 toque: pausa/continua (imediato, sem esperar o duplo toque)
                    @Override public boolean onSingleTapUp(MotionEvent e) {
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                        toggle();
                        return true;
                    }

                    // 2 toques: reinicia
                    @Override public boolean onDoubleTap(MotionEvent e) {
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                        reset();
                        return true;
                    }

                    // arrastar
                    @Override public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                                      float dx, float dy) {
                        if (e1 == null) return false;
                        moveTo(ix + (int) (e2.getRawX() - e1.getRawX()),
                               iy + (int) (e2.getRawY() - e1.getRawY()));
                        return true;
                    }
                });

        view.setOnTouchListener((v, ev) -> {
            gd.onTouchEvent(ev);
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                Prefs.get(this).edit().putInt(Prefs.POS_X, lp.x).putInt(Prefs.POS_Y, lp.y).apply();
            }
            return true;
        });

        wm.addView(view, lp);
        refresh();
    }

    // ---------- notificação obrigatória do serviço em primeiro plano ----------

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Cronômetro", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Cronômetro flutuante ativo")
                .setContentText("Toque para abrir as configurações")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }
}
