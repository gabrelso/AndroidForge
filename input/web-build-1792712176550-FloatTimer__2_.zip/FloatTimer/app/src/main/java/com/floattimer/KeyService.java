package com.floattimer;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/** Captura as teclas configuradas em qualquer app: iniciar/pausar e reiniciar. */
public class KeyService extends AccessibilityService {

    private SharedPreferences prefs;
    private volatile int toggleKey = KeyEvent.KEYCODE_UNKNOWN;
    private volatile int resetKey = KeyEvent.KEYCODE_UNKNOWN;

    // referência forte: o SharedPreferences guarda listeners só com referência fraca
    private final SharedPreferences.OnSharedPreferenceChangeListener listener =
            (p, key) -> load();

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = Prefs.get(this);
        prefs.registerOnSharedPreferenceChangeListener(listener);
        load();
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(listener);
        return super.onUnbind(intent);
    }

    private void load() {
        toggleKey = prefs.getInt(Prefs.KEY_TOGGLE, KeyEvent.KEYCODE_UNKNOWN);
        resetKey = prefs.getInt(Prefs.KEY_RESET, KeyEvent.KEYCODE_UNKNOWN);
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean isToggle = toggleKey != KeyEvent.KEYCODE_UNKNOWN && code == toggleKey;
        boolean isReset = resetKey != KeyEvent.KEYCODE_UNKNOWN && code == resetKey;
        if (!isToggle && !isReset) return false;

        TimerService t = TimerService.instance;
        if (t == null) return false; // cronômetro escondido: deixa a tecla passar normalmente

        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            if (isToggle) t.toggle(); else t.restart();
        }
        return true; // consome a tecla (não chega ao jogo / não muda o volume)
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }
}
