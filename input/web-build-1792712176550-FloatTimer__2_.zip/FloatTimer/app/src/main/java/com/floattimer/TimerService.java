package com.floattimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Locale;

public class TimerService extends Service {

    /** Acessível pelo KeyService (mesmo processo, thread principal). */
    public static volatile TimerService instance;

    private static final String CHANNEL = "timer";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView view;
    private WindowManager.LayoutParams lp;

    private boolean running = false;
    private long startNanos = 0;   // relógio no último "start"
    private long accumNanos = 0;   // tempo acumulado até a última pausa

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            render();
            if (running) handler.postDelayed(this, 16);
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (view == null) createOverlay();
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        instance = null;
        handler.removeCallbacks(tick);
        if (view != null && wm != null) {
            try { wm.removeView(view); } catch (Exception ignored) { }
            view = null;
        }
        super.onDestroy();
    }

    // ---------- controle do cronômetro ----------

    /** Inicia / pausa. */
    public void toggle() {
        long now = SystemClock.elapsedRealtimeNanos();
        if (running) {
            accumNanos += now - startNanos;
            running = false;
            handler.removeCallbacks(tick);
            render();
        } else {
            startNanos = now;
            running = true;
            handler.post(tick);
        }
    }

    /** Zera e já começa a contar de novo (usado pela tecla de reiniciar). */
    public void restart() {
        accumNanos = 0;
        startNanos = SystemClock.elapsedRealtimeNanos();
        running = true;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    /** Zera e para (usado pelo duplo toque). */
    public void reset() {
        running = false;
        accumNanos = 0;
        handler.removeCallbacks(tick);
        render();
    }

    private long elapsedMs() {
        long n = accumNanos;
        if (running) n += SystemClock.elapsedRealtimeNanos() - startNanos;
        return n / 1_000_000L;
    }

    private void render() {
        if (view == null) return;
        long ms = elapsedMs();
        long h = ms / 3_600_000L;
        long m = (ms / 60_000L) % 60;
        long s = (ms / 1000L) % 60;
        long r = ms % 1000;
        view.setText(String.format(Locale.US, "%d:%02d:%02d.%03d", h, m, s, r));
    }

    // ---------- overlay ----------

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private void createOverlay() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        view = new TextView(this);
        view.setTextColor(Color.WHITE);
        view.setBackgroundColor(Color.BLACK);
        view.setTypeface(Typeface.MONOSPACE);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        view.setPadding(dp(8), dp(3), dp(8), dp(3));
        view.setText("0:00:00.000");

        SharedPreferences sp = Prefs.get(this);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = sp.getInt(Prefs.POS_X, dp(16));
        lp.y = sp.getInt(Prefs.POS_Y, dp(40));

        final GestureDetector gd = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    int ix, iy;

                    @Override public boolean onDown(MotionEvent e) {
                        ix = lp.x;
                        iy = lp.y;
                        return true;
                    }

                    // 1 toque: pausa/continua (imediato, sem esperar o duplo toque)
                    @Override public boolean onSingleTapUp(MotionEvent e) {
                        toggle();
                        return true;
                    }

                    // 2 toques: reinicia (zera e para)
                    @Override public boolean onDoubleTap(MotionEvent e) {
                        reset();
                        return true;
                    }

                    // arrastar
                    @Override public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                                      float dx, float dy) {
                        if (e1 == null) return false;
                        lp.x = ix + (int) (e2.getRawX() - e1.getRawX());
                        lp.y = iy + (int) (e2.getRawY() - e1.getRawY());
                        wm.updateViewLayout(view, lp);
                        return true;
                    }
                });

        view.setOnTouchListener((v, ev) -> {
            gd.onTouchEvent(ev);
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                Prefs.get(this).edit()
                        .putInt(Prefs.POS_X, lp.x).putInt(Prefs.POS_Y, lp.y).apply();
            }
            return true;
        });

        wm.addView(view, lp);
    }

    // ---------- notificação obrigatória do serviço em primeiro plano ----------

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Cronômetro", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Cronômetro flutuante ativo")
                .setContentText("Toque para abrir as configurações")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }
}
