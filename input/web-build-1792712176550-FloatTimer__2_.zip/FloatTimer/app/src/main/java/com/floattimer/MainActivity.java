package com.floattimer;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private static final int BG = 0xFF121212;
    private static final int CARD = 0xFF1E1E1E;
    private static final int BTN = 0xFF2E2E2E;
    private static final int ACCENT = 0xFF4F8CFF;
    private static final int OK = 0xFF4CAF50;
    private static final int BAD = 0xFFFF7043;
    private static final int TXT = 0xFFFFFFFF;
    private static final int SUB = 0xFF9E9E9E;
    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView overlayStatus, a11yStatus, toggleKeyLabel, resetKeyLabel;
    private Button showBtn;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));

        root.addView(text("Cronômetro Flutuante", 24, TXT, true));
        TextView sub = text("Um cronômetro por cima de qualquer app", 14, SUB, false);
        sub.setPadding(0, dp(2), 0, dp(8));
        root.addView(sub);

        // --- pré-visualização ---
        root.addView(section("PRÉ-VISUALIZAÇÃO"));
        LinearLayout previewCard = card();
        previewCard.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView preview = text("0:00:00.000", 16, Color.WHITE, false);
        preview.setTypeface(Typeface.MONOSPACE);
        preview.setBackgroundColor(Color.BLACK);
        preview.setPadding(dp(8), dp(3), dp(8), dp(3));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(WRAP, WRAP);
        pp.topMargin = dp(8);
        previewCard.addView(preview, pp);
        TextView hint = text("1 toque: pausar/continuar  ·  2 toques: reiniciar  ·  arraste para mover",
                12, SUB, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(12), 0, dp(8));
        previewCard.addView(hint);
        root.addView(previewCard);

        // --- permissões ---
        root.addView(section("PERMISSÕES"));
        LinearLayout perms = card();
        overlayStatus = text("", 13, SUB, false);
        perms.addView(row(stack("Sobreposição de tela", overlayStatus),
                btn("Ajustes", BTN, v -> startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()))))));
        perms.addView(divider());
        a11yStatus = text("", 13, SUB, false);
        perms.addView(row(stack("Serviço de acessibilidade", a11yStatus),
                btn("Ajustes", BTN,
                        v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))));
        root.addView(perms);

        // --- teclas ---
        root.addView(section("TECLAS"));
        LinearLayout keys = card();
        toggleKeyLabel = text("", 13, SUB, false);
        keys.addView(row(stack("Iniciar / pausar", toggleKeyLabel),
                btn("Definir", BTN, v -> askKey(Prefs.KEY_TOGGLE, Prefs.KEY_RESET)),
                btn("✕", BTN, v -> clearKey(Prefs.KEY_TOGGLE))));
        keys.addView(divider());
        resetKeyLabel = text("", 13, SUB, false);
        keys.addView(row(stack("Reiniciar e iniciar", resetKeyLabel),
                btn("Definir", BTN, v -> askKey(Prefs.KEY_RESET, Prefs.KEY_TOGGLE)),
                btn("✕", BTN, v -> clearKey(Prefs.KEY_RESET))));
        root.addView(keys);
        TextView keyHint = text("As teclas só funcionam dentro de outros apps com o serviço de "
                + "acessibilidade ativo e o cronômetro visível.", 12, SUB, false);
        keyHint.setPadding(dp(4), dp(2), dp(4), dp(8));
        root.addView(keyHint);

        // --- mostrar / esconder ---
        showBtn = btn("", ACCENT, v -> toggleOverlay());
        showBtn.setTextSize(16);
        showBtn.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(MATCH, WRAP);
        sp.topMargin = dp(8);
        root.addView(showBtn, sp);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshAll();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------- ações ----------

    private void toggleOverlay() {
        if (TimerService.instance != null) {
            stopService(new Intent(this, TimerService.class));
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permita a sobreposição de tela primeiro",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            startForegroundService(new Intent(this, TimerService.class));
        }
        handler.postDelayed(this::refreshAll, 300);
    }

    private void askKey(final String prefKey, final String otherKey) {
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Definir tecla")
                .setMessage("Pressione a tecla desejada…\n(Voltar cancela)")
                .setNegativeButton("Cancelar", null)
                .create();
        d.setOnKeyListener((dialog, code, ev) -> {
            if (ev.getAction() == KeyEvent.ACTION_DOWN && code != KeyEvent.KEYCODE_BACK) {
                if (code == Prefs.get(this).getInt(otherKey, KeyEvent.KEYCODE_UNKNOWN)) {
                    Toast.makeText(this, "Essa tecla já é usada na outra ação",
                            Toast.LENGTH_SHORT).show();
                    return true;
                }
                Prefs.get(this).edit().putInt(prefKey, code).apply();
                d.dismiss();
                refreshAll();
                return true;
            }
            return false;
        });
        d.show();
    }

    private void clearKey(String prefKey) {
        Prefs.get(this).edit().remove(prefKey).apply();
        refreshAll();
    }

    // ---------- estado ----------

    private void refreshAll() {
        setStatus(overlayStatus, Settings.canDrawOverlays(this), "Permitida", "Não permitida");
        setStatus(a11yStatus, isAccessibilityEnabled(), "Ativo", "Desativado");
        setKeyLabel(toggleKeyLabel, Prefs.KEY_TOGGLE);
        setKeyLabel(resetKeyLabel, Prefs.KEY_RESET);
        showBtn.setText(TimerService.instance != null ? "Esconder cronômetro"
                : "Mostrar cronômetro");
    }

    private void setStatus(TextView tv, boolean ok, String okText, String badText) {
        tv.setText(ok ? "✓ " + okText : "✕ " + badText);
        tv.setTextColor(ok ? OK : BAD);
    }

    private void setKeyLabel(TextView tv, String prefKey) {
        int k = Prefs.get(this).getInt(prefKey, KeyEvent.KEYCODE_UNKNOWN);
        if (k == KeyEvent.KEYCODE_UNKNOWN) {
            tv.setText("Nenhuma");
            tv.setTextColor(SUB);
        } else {
            tv.setText(KeyEvent.keyCodeToString(k).replace("KEYCODE_", "").replace('_', ' '));
            tv.setTextColor(ACCENT);
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = getSystemService(AccessibilityManager.class);
        if (am == null) return false;
        List<AccessibilityServiceInfo> list =
                am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo i : list) {
            ServiceInfo si = i.getResolveInfo().serviceInfo;
            if (si.packageName.equals(getPackageName())
                    && si.name.equals(KeyService.class.getName())) {
                return true;
            }
        }
        return false;
    }

    // ---------- helpers de UI ----------

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView section(String s) {
        TextView t = text(s, 12, SUB, true);
        t.setLetterSpacing(0.1f);
        t.setPadding(dp(4), dp(16), 0, dp(8));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        c.setBackground(g);
        c.setPadding(dp(16), dp(8), dp(16), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(4);
        c.setLayoutParams(lp);
        return c;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(0x1FFFFFFF);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(1))));
        return v;
    }

    private LinearLayout stack(String title, TextView sub) {
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.VERTICAL);
        s.addView(text(title, 16, TXT, false));
        s.addView(sub);
        return s;
    }

    private LinearLayout row(View left, View... right) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, dp(10));
        r.addView(left, new LinearLayout.LayoutParams(0, WRAP, 1f));
        for (View v : right) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(WRAP, WRAP);
            p.leftMargin = dp(8);
            r.addView(v, p);
        }
        return r;
    }

    private Button btn(String label, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setStateListAnimator(null);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(12));
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.WHITE);
        mask.setCornerRadius(dp(12));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, mask));
        b.setOnClickListener(l);
        return b;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }
}
