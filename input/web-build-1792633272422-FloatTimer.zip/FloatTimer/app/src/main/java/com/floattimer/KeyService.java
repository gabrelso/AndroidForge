package com.floattimer;

import android.accessibilityservice.AccessibilityService;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/** Captura a tecla configurada em qualquer app e aciona início/pausa. */
public class KeyService extends AccessibilityService {

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int bound = getSharedPreferences("prefs", MODE_PRIVATE)
                .getInt("key", KeyEvent.KEYCODE_UNKNOWN);
        TimerService t = TimerService.instance;
        if (bound == KeyEvent.KEYCODE_UNKNOWN || t == null) return false;
        if (e.getKeyCode() != bound) return false;

        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            t.toggle();
        }
        return true; // consome a tecla (não chega ao jogo / não muda o volume)
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }
}
