package com.floattimer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView keyLabel;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        root.setPadding(p, p, p, p);

        TextView help = new TextView(this);
        help.setText("1) Permita a sobreposição\n"
                + "2) Defina a tecla de iniciar/pausar\n"
                + "3) Ative o serviço de acessibilidade (necessário só para a tecla funcionar "
                + "dentro de outros apps)\n"
                + "4) Mostre o cronômetro\n\n"
                + "No cronômetro: 1 toque = pausar/continuar, 2 toques = reiniciar, "
                + "arrastar = mover.");
        root.addView(help);

        addButton(root, "Permitir sobreposição de tela", v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));

        keyLabel = new TextView(this);
        keyLabel.setPadding(0, dp(16), 0, 0);
        root.addView(keyLabel);
        addButton(root, "Definir tecla de iniciar/pausar", v -> askKey());
        addButton(root, "Remover tecla", v -> {
            getSharedPreferences("prefs", MODE_PRIVATE).edit().remove("key").apply();
            refreshKeyLabel();
        });

        addButton(root, "Ativar serviço de acessibilidade",
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        addButton(root, "Mostrar cronômetro", v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permita a sobreposição primeiro", Toast.LENGTH_SHORT).show();
                return;
            }
            startForegroundService(new Intent(this, TimerService.class));
        });
        addButton(root, "Esconder cronômetro",
                v -> stopService(new Intent(this, TimerService.class)));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshKeyLabel();
    }

    private void refreshKeyLabel() {
        int k = getSharedPreferences("prefs", MODE_PRIVATE)
                .getInt("key", KeyEvent.KEYCODE_UNKNOWN);
        keyLabel.setText(k == KeyEvent.KEYCODE_UNKNOWN
                ? "Tecla: nenhuma"
                : "Tecla: " + KeyEvent.keyCodeToString(k));
    }

    private void askKey() {
        final AlertDialog d = new AlertDialog.Builder(this)
                .setMessage("Pressione a tecla desejada…\n(Voltar cancela)")
                .setNegativeButton("Cancelar", null)
                .create();
        d.setOnKeyListener((dialog, code, ev) -> {
            if (ev.getAction() == KeyEvent.ACTION_DOWN && code != KeyEvent.KEYCODE_BACK) {
                getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("key", code).apply();
                d.dismiss();
                refreshKeyLabel();
                return true;
            }
            return false;
        });
        d.show();
    }

    private void addButton(LinearLayout parent, String text, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setOnClickListener(l);
        parent.addView(btn);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }
}
