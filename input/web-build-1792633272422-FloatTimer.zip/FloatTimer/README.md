# Cronômetro Flutuante

Cronômetro `h:mm:ss.mmm`, fundo preto / texto branco, flutuante e arrastável.

- 1 toque: pausa / continua
- 2 toques: reinicia (zera e para)
- Arrastar: move (a posição é lembrada)
- Tecla configurável: inicia / pausa (funciona dentro de outros apps via serviço de acessibilidade)

## Como gerar o APK

**Opção A – GitHub (sem instalar nada)**
1. Crie um repositório e suba o conteúdo desta pasta.
2. Aba *Actions* → *Build APK* → rode (ou apenas faça o push).
3. Baixe o artefato `cronometro-apk` (contém `app-debug.apk`, já instalável).

**Opção B – Android Studio**
File → Open → escolha esta pasta → Build → Build APK(s).

## Uso
1. Abra o app → *Permitir sobreposição de tela*.
2. *Definir tecla* e pressione a tecla desejada.
3. *Ativar serviço de acessibilidade* → Cronômetro Flutuante → ligar.
   No Android 13+ de app instalado fora da Play Store, pode ser preciso antes ir em
   Configurações → Apps → Cronômetro Flutuante → ⋮ → "Permitir configurações restritas".
4. *Mostrar cronômetro*.

A tecla escolhida é consumida enquanto o cronômetro estiver visível (não chega ao jogo).
