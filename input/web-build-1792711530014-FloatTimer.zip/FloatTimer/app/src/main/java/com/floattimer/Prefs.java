package com.floattimer;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String NAME = "prefs";
    static final String KEY_TOGGLE = "key";        // iniciar / pausar
    static final String KEY_RESET = "key_reset";   // reiniciar
    static final String POS_X = "x";
    static final String POS_Y = "y";

    private Prefs() { }

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
}
