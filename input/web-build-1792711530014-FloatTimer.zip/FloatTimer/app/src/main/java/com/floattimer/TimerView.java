package com.floattimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

/**
 * Display do cronômetro desenhado direto no Canvas: horas/min/seg em destaque,
 * milissegundos menores e mais discretos. Não aloca objetos a cada atualização.
 */
public class TimerView extends View {

    public static final int IDLE = 0;
    public static final int RUNNING = 1;
    public static final int PAUSED = 2;

    private static final int COLOR_MAIN = 0xFFFFFFFF;
    private static final int COLOR_MS = 0xFF8F8F8F;
    private static final int COLOR_PAUSED = 0xFFFFC107;
    private static final int COLOR_PAUSED_MS = 0xFFB8860B;

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint main = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ms = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private final char[] mainBuf = new char[24];
    private final char[] msBuf = {'.', '0', '0', '0'};
    private int mainLen = 7;           // "0:00:00"

    private int state = -1;
    private long shownMs = -1;

    private final float padH, padV, radius, strokeW;
    private final float charMain, charMs, baseline, contentH;

    public TimerView(Context c) {
        super(c);
        padH = dp(10);
        padV = dp(5);
        radius = dp(10);
        strokeW = dp(1);

        bg.setColor(0xFF000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(strokeW);
        stroke.setColor(0x26FFFFFF);

        main.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        main.setTextSize(sp(18));
        ms.setTypeface(Typeface.MONOSPACE);
        ms.setTextSize(sp(12));

        charMain = main.measureText("0");
        charMs = ms.measureText("0");
        Paint.FontMetrics fm = main.getFontMetrics();
        baseline = padV - fm.ascent;
        contentH = fm.descent - fm.ascent;

        update(0, IDLE);
    }

    /** Atualiza o que é exibido; só redesenha se algo mudou. */
    public void update(long totalMs, int newState) {
        if (totalMs == shownMs && newState == state) return;
        if (newState != state) {
            state = newState;
            boolean p = state == PAUSED;
            main.setColor(p ? COLOR_PAUSED : COLOR_MAIN);
            ms.setColor(p ? COLOR_PAUSED_MS : COLOR_MS);
        }
        if (totalMs != shownMs) {
            shownMs = totalMs;
            format(totalMs);
        }
        invalidate();
    }

    private void format(long t) {
        long h = Math.min(t / 3_600_000L, 999L);
        int p = putNum(mainBuf, 0, h);
        mainBuf[p++] = ':';
        p = put2(mainBuf, p, (int) ((t / 60_000L) % 60));
        mainBuf[p++] = ':';
        p = put2(mainBuf, p, (int) ((t / 1000L) % 60));
        if (p != mainLen) {
            mainLen = p;
            requestLayout();
        }
        int r = (int) (t % 1000);
        msBuf[1] = (char) ('0' + r / 100);
        msBuf[2] = (char) ('0' + (r / 10) % 10);
        msBuf[3] = (char) ('0' + r % 10);
    }

    private static int putNum(char[] b, int pos, long v) {
        int d = 1;
        for (long x = v; x >= 10; x /= 10) d++;
        for (int i = d - 1; i >= 0; i--) {
            b[pos + i] = (char) ('0' + (int) (v % 10));
            v /= 10;
        }
        return pos + d;
    }

    private static int put2(char[] b, int pos, int v) {
        b[pos] = (char) ('0' + v / 10);
        b[pos + 1] = (char) ('0' + v % 10);
        return pos + 2;
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int w = (int) Math.ceil(padH * 2 + charMain * mainLen + charMs * 4);
        int h = (int) Math.ceil(padV * 2 + contentH);
        setMeasuredDimension(w, h);
    }

    @Override protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        rect.set(0, 0, w, h);
        canvas.drawRoundRect(rect, radius, radius, bg);
        float in = strokeW / 2f;
        rect.set(in, in, w - in, h - in);
        canvas.drawRoundRect(rect, radius, radius, stroke);

        canvas.drawText(mainBuf, 0, mainLen, padH, baseline, main);
        canvas.drawText(msBuf, 0, 4, padH + charMain * mainLen, baseline, ms);
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                getResources().getDisplayMetrics());
    }
}
